import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BtmodalPage } from './btmodal';

@NgModule({
  declarations: [
    BtmodalPage,
  ],
  imports: [
    IonicPageModule.forChild(BtmodalPage),
  ],
})
export class BtmodalPageModule {}
